//
//  NSString+TBTokenizer.h
//  BertTokenizer
//
//  Created by 谭健康 on 2022/5/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (TBTokenizer)

//根据空格分割
- (NSArray <NSString *> *)tb_whiteSpaceTokenize;
//根据特殊字符分割
- (NSArray <NSString *> *)tb_runSplitOnPunc;
//是否是中文
- (BOOL)tb_isChineseChar;

- (BOOL)tb_isWhiteSpace;
// 全角转半角
- (NSString *)tb_convertFullWidthToHalfWidth;
- (NSString *)tb_rstrip;
- (NSString *)tb_lstrip;
@end

NS_ASSUME_NONNULL_END
